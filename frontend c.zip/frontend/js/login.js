const form = document.getElementById("loginForm");

form.addEventListener("submit", async function(e){

    e.preventDefault();

    const email = document.getElementById("email").value;

    const password = document.getElementById("password").value;

    const result = await loginUser(email, password);

    console.log(result);

    console.log("Access Token =", result.access_token);
    if(result.access_token){

        localStorage.setItem("token", result.access_token);

        alert("Login Success");

        window.location.href = "index.html";
    }else{

        alert(result.message);

    }

});