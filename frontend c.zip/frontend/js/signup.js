const form = document.getElementById("signupForm");

form.addEventListener("submit", async (e) => {

    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const result = await registerUser(name, email, password);

    alert(result.message);

    if (result.message === "User Registered Successfully") {

        window.location.href = "login.html";

    }

});