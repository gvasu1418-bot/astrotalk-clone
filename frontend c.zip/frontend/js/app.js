window.onload = async () => {

    console.log("AstroTalk Loaded 🚀");

    const loginBtn = document.getElementById("loginBtn");
    const signupBtn = document.getElementById("signupBtn");
    const logoutBtn = document.getElementById("logoutBtn");
    const aiBtn = document.getElementById("startAI");

    // AI Button
    if (aiBtn) {
        aiBtn.addEventListener("click", () => {
            alert("🤖 AI Chat Coming Soon...");
        });
    }

    // Login / Signup Button
    if (loginBtn) {
        loginBtn.addEventListener("click", () => {
            window.location.href = "login.html";
        });
    }

    if (signupBtn) {
        signupBtn.addEventListener("click", () => {
            window.location.href = "signup.html";
        });
    }

    // Logout
    if (logoutBtn) {

        logoutBtn.style.display = "none";

        logoutBtn.addEventListener("click", () => {

            localStorage.removeItem("token");

            window.location.href = "login.html";

        });

    }

    // Check Login
    const token = localStorage.getItem("token");

    if (token) {
        await loadProfile();
    }

};

// ================= PROFILE =================

async function loadProfile() {

    try {

        const profile = await getProfile();

        console.log(profile);

        if (profile.name) {

            document.getElementById("username").innerHTML =
                "👋 " + profile.name;

            document.getElementById("loginBtn").style.display = "none";

            document.getElementById("signupBtn").style.display = "none";

            document.getElementById("logoutBtn").style.display = "inline-block";

        }

    } catch (error) {

        console.log(error);

    }

}