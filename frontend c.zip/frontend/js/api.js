const API_URL = "http://127.0.0.1:8000";

async function loginUser(email, password) {
  

    try {

        const response = await fetch(`${API_URL}/login`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email: email,
                password: password
            })

        });

        return await response.json();

    } catch (error) {

        console.error(error);

    }

}

async function registerUser(name, email, password) {

    try {

        const response = await fetch(`${API_URL}/register`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                name,
                email,
                password
            })

        });

        return await response.json();

    } catch (error) {

        console.error(error);

    }

}

// ================= PROFILE =================

async function getProfile() {

    const token = localStorage.getItem("token");

    const response = await fetch(`${API_URL}/profile`, {

        method: "GET",

        headers: {
            "Authorization": `Bearer ${token}`
        }

    });

    return await response.json();

}