("=== START ===")

from app.core.settings import DATABASE_URL
print(DATABASE_URL)

print("=== DATABASE LOADED ===")


from fastapi import FastAPI

from fastapi.middleware.cors import CORSMiddleware


from app.database.base import Base
from app.database.connection import engine

from app.models.user import User
from app.models.astrologer import Astrologer
from app.models.booking import Booking
from app.models.wallet import Wallet
from app.models.review import Review

from api.user import router as user_router
from api.astrologer import router as astrologer_router
from api.booking import router as booking_router
from api.wallet import router as wallet_router
from api.review import router as review_router
from api.stats import router as stats_router
from api.admin import router as admin_router

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
Base.metadata.create_all(bind=engine)

app.include_router(user_router)
app.include_router(astrologer_router)
app.include_router(booking_router)


@app.get("/")
def home():
    return {
        "message": "AstroTalk Backend Running"
    }
    
Base.metadata.create_all(bind=engine)

app.include_router(wallet_router) 
app.include_router(review_router)
app.include_router(stats_router)
app.include_router(admin_router)
print